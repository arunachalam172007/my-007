# ForgeAI Project Generator
React/Vite frontend and FastAPI backend for AI project generation, file preview, ZIP export, and GitHub OAuth publishing.

## Requirements
Node.js 20+, Python 3.11+. Copy `backend/.env.example` to `backend/.env` and configure credentials.

## Run
Backend: `cd backend`; create/activate venv; `pip install -r requirements.txt`; `uvicorn app.main:app --reload --port 8000`.
Frontend: `cd frontend && npm install && npm run dev`; open Vite's local URL. Vite proxies `/api` to port 8000.

## Credentials
Set AI_BASE_URL to an OpenAI-compatible API base, AI_API_KEY, and AI_MODEL. Create a GitHub OAuth App with callback `http://localhost:8000/api/github/callback`; set client ID and secret. The OAuth flow validates state and uses an HttpOnly session cookie. It requests `repo` scope for private repo publishing; production should use HTTPS, a persistent session store, rate limiting, and ideally a GitHub App with narrow permissions.

## API
POST `/api/projects/analyze`; POST `/api/projects/generate`; GET `/api/projects/{id}/files`; GET `/api/projects/{id}/files/{path}`; GET `/api/projects/{id}/download`; GET `/api/github/login`; GET `/api/github/callback`; GET `/api/github/status`; GET `/api/github/repositories`; POST `/api/github/publish`.

PDF/DOCX/TXT/MD and common image upload are supported; image OCR is not configured. Generated source is untrusted; review before running. Uploads are size-limited. ZIP and GitHub publishing exclude `.env`, credentials, dependency/build folders, and caches. Publishing requires explicit confirmation. AI/GitHub operations require your own credentials and external connectivity.

## Tests
`cd backend && pip install pytest && pytest`.
