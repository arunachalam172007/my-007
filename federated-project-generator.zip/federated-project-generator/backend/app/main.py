import os, re, json, uuid, base64, secrets, zipfile, io
from pathlib import Path
from urllib.parse import urlencode
import httpx
from fastapi import FastAPI, UploadFile, File, Form, Request, HTTPException, Depends
from fastapi.responses import RedirectResponse, FileResponse
from fastapi.middleware.cors import CORSMiddleware
from itsdangerous import URLSafeSerializer, BadSignature
from pydantic import BaseModel, Field
app=FastAPI(title='ForgeAI Project Generator')
FRONT=os.getenv('FRONTEND_URL','http://localhost:5173'); STORE=Path(os.getenv('PROJECT_STORAGE','./projects')).resolve(); STORE.mkdir(parents=True,exist_ok=True)
app.add_middleware(CORSMiddleware,allow_origins=[FRONT],allow_credentials=True,allow_methods=['GET','POST'],allow_headers=['Content-Type'])
signer=URLSafeSerializer(os.getenv('SESSION_SECRET','change-this-secret'),salt='session'); projects={}; MAX=int(os.getenv('MAX_UPLOAD_MB','12'))*1024*1024
class Generate(BaseModel): topic:str=Field(min_length=5,max_length=20000); language:str='Python + React'; framework:str='FastAPI + React'; specification:str|None=None
class Publish(BaseModel): project_id:str; owner:str; repo:str; branch:str='main'; description:str=''; visibility:str='private'; create_repo:bool=False; confirmed:bool=False
def safe_path(p):
 if not isinstance(p,str) or not p or p.startswith(('/','\\')) or '\\' in p: raise ValueError('Unsafe path')
 parts=p.split('/')
 if any(x in ('','.','..') for x in parts) or not re.fullmatch(r'[A-Za-z0-9._/@+-]+',p): raise ValueError('Invalid path')
 if p.lower()=='.env' or (p.lower().startswith('.env.') and not p.lower().endswith('.env.example')): raise ValueError('Secrets excluded')
 if any(x.lower() in {'node_modules','.git','__pycache__','.venv','dist','build'} for x in parts): raise ValueError('Build/dependency folders excluded')
 return p
def sess(r):
 try:return signer.loads(r.cookies.get('session',''))
 except BadSignature:return {}
def gh_token(r):
 t=sess(r).get('github_token')
 if not t:raise HTTPException(401,'Connect GitHub first')
 return t
def get_project(pid):
 p=projects.get(pid)
 if not p or not p.exists():raise HTTPException(404,'Project not found')
 return p
@app.get('/api/health')
def health():return {'status':'ok'}
@app.post('/api/projects/analyze')
async def analyze(topic:str=Form(''),language:str=Form('Python + React'),upload:UploadFile|None=File(None)):
 spec=topic.strip()
 if upload and upload.filename:
  data=await upload.read()
  if len(data)>MAX:raise HTTPException(413,'Upload too large')
  n=upload.filename.lower()
  try:
   if n.endswith(('.txt','.md')):txt=data.decode('utf-8-sig')
   elif n.endswith('.pdf'):
    from pypdf import PdfReader
    txt='\n'.join(p.extract_text() or '' for p in PdfReader(io.BytesIO(data)).pages)
   elif n.endswith('.docx'):
    from docx import Document
    txt='\n'.join(p.text for p in Document(io.BytesIO(data)).paragraphs)
   elif n.endswith(('.png','.jpg','.jpeg','.webp')):
    from PIL import Image
    im=Image.open(io.BytesIO(data));im.verify();txt='Image upload: OCR is not configured; describe it in the topic.'
   else:raise HTTPException(415,'Supported: PDF, DOCX, TXT, MD, PNG, JPG, WEBP')
  except HTTPException:raise
  except Exception as e:raise HTTPException(400,'Document parsing failed: '+str(e))
  spec+='\n\nUploaded specification:\n'+txt[:100000]
 if len(spec)<5:raise HTTPException(400,'Enter a topic or upload requirements')
 return {'specification':spec,'language':language,'summary':spec[:1200]}
@app.post('/api/projects/generate')
async def generate(req:Generate):
 key=os.getenv('AI_API_KEY');base=os.getenv('AI_BASE_URL','https://api.openai.com/v1').rstrip('/')
 if not key or key=='replace_me':raise HTTPException(503,'Configure AI_API_KEY, AI_BASE_URL and AI_MODEL in backend/.env')
 prompt='Create complete runnable project. Return only JSON {"files":[{"path":"relative/path","content":"..."}]}. Include README, .gitignore, .env.example, manifests, tests and relevant frontend/backend. Exclude secrets, .env, dependencies, caches, build outputs and binaries. Topic: '+req.topic+'\n'+(req.specification or '')+'\nLanguage: '+req.language+'; framework: '+req.framework
 try:
  async with httpx.AsyncClient(timeout=180) as c:r=await c.post(base+'/chat/completions',headers={'Authorization':'Bearer '+key},json={'model':os.getenv('AI_MODEL','gpt-4o-mini'),'temperature':0.2,'response_format':{'type':'json_object'},'messages':[{'role':'system','content':'Senior software engineer. Return valid JSON only.'},{'role':'user','content':prompt}]})
  if r.status_code>=400:raise HTTPException(r.status_code,'AI provider error: '+r.text[:350])
  items=json.loads(r.json()['choices'][0]['message']['content']).get('files')
  if not isinstance(items,list) or not 1<=len(items)<=100:raise ValueError('Invalid file list')
  content={}
  for item in items:
   p=safe_path(item.get('path'));v=item.get('content')
   if not isinstance(v,str) or len(v)>500000:raise ValueError('Invalid file content')
   if re.search(r'(sk-[A-Za-z0-9]{20,}|gh[pousr]_[A-Za-z0-9]{20,}|-----BEGIN .*PRIVATE KEY-----)',v):raise ValueError('Potential secret detected')
   content[p]=v
  if sum(len(v.encode()) for v in content.values())>5000000:raise ValueError('Project exceeds 5 MB')
 except HTTPException:raise
 except Exception as e:raise HTTPException(502,'Generation failed: '+str(e)[:300])
 pid=str(uuid.uuid4());folder=STORE/pid;folder.mkdir()
 for p,v in content.items():f=folder/p;f.parent.mkdir(parents=True,exist_ok=True);f.write_text(v,encoding='utf-8')
 projects[pid]=folder
 return {'project_id':pid,'count':len(content),'files':[{'path':p,'size':len(v.encode())} for p,v in content.items()]}
@app.get('/api/projects/{pid}/files')
def files(pid:str):
 p=get_project(pid);return {'files':[{'path':f.relative_to(p).as_posix(),'size':f.stat().st_size} for f in p.rglob('*') if f.is_file()]}
@app.get('/api/projects/{pid}/files/{path:path}')
def preview(pid:str,path:str):
 p=get_project(pid)
 try:f=(p/safe_path(path)).resolve()
 except ValueError as e:raise HTTPException(400,str(e))
 if not f.is_relative_to(p) or not f.is_file():raise HTTPException(404,'File not found')
 if f.stat().st_size>700000:raise HTTPException(413,'Preview too large')
 return {'path':path,'content':f.read_text(encoding='utf-8',errors='replace')}
@app.get('/api/projects/{pid}/download')
def download(pid:str):
 p=get_project(pid);z=STORE/(pid+'.zip')
 with zipfile.ZipFile(z,'w',zipfile.ZIP_DEFLATED) as a:
  for f in p.rglob('*'):
   if f.is_file():
    rel=f.relative_to(p).as_posix()
    try:safe_path(rel)
    except ValueError:continue
    a.write(f,pid+'/'+rel)
 return FileResponse(z,filename='generated-project.zip',media_type='application/zip')
@app.get('/api/github/login')
def login():
 cid=os.getenv('GITHUB_CLIENT_ID');cb=os.getenv('GITHUB_CALLBACK_URL')
 if not cid or cid=='replace_me':raise HTTPException(503,'GitHub OAuth not configured')
 state=secrets.token_urlsafe(32);r=RedirectResponse('https://github.com/login/oauth/authorize?'+urlencode({'client_id':cid,'redirect_uri':cb,'scope':'repo','state':state}))
 r.set_cookie('oauth_state',state,httponly=True,samesite='lax',secure=cb.startswith('https://'),max_age=600);return r
@app.get('/api/github/callback')
async def callback(request:Request,code:str='',state:str=''):
 expected=request.cookies.get('oauth_state','')
 if not expected or not secrets.compare_digest(expected,state):raise HTTPException(400,'OAuth state validation failed')
 async with httpx.AsyncClient(timeout=30) as c:r=await c.post('https://github.com/login/oauth/access_token',headers={'Accept':'application/json'},json={'client_id':os.getenv('GITHUB_CLIENT_ID'),'client_secret':os.getenv('GITHUB_CLIENT_SECRET'),'code':code})
 if r.status_code>=400 or not r.json().get('access_token'):raise HTTPException(502,'GitHub OAuth exchange failed')
 out=RedirectResponse(FRONT+'/?github=connected');out.set_cookie('session',signer.dumps({'github_token':r.json()['access_token']}),httponly=True,samesite='lax',secure=os.getenv('GITHUB_CALLBACK_URL','').startswith('https://'),max_age=86400);out.delete_cookie('oauth_state');return out
@app.get('/api/github/status')
def status(request:Request):return {'connected':bool(sess(request).get('github_token'))}
@app.get('/api/github/repositories')
async def repositories(t=Depends(gh_token)):
 async with httpx.AsyncClient(timeout=30) as c:r=await c.get('https://api.github.com/user/repos?per_page=100',headers={'Authorization':'Bearer '+t,'Accept':'application/vnd.github+json'})
 if r.status_code>=400:raise HTTPException(r.status_code,'GitHub listing error: '+r.text[:300])
 return {'repositories':[{'full_name':x['full_name'],'default_branch':x['default_branch'],'private':x['private']} for x in r.json()]}
@app.post('/api/github/publish')
async def publish(req:Publish,t=Depends(gh_token)):
 if not req.confirmed:raise HTTPException(400,'Confirm publishing first')
 if not re.fullmatch(r'[A-Za-z0-9_.-]{1,100}',req.repo):raise HTTPException(400,'Invalid repository')
 if not re.fullmatch(r'[A-Za-z0-9._/-]{1,200}',req.branch) or '..' in req.branch.split('/'):raise HTTPException(400,'Invalid branch')
 p=get_project(req.project_id);h={'Authorization':'Bearer '+t,'Accept':'application/vnd.github+json','X-GitHub-Api-Version':'2022-11-28'}
 async with httpx.AsyncClient(timeout=60) as c:
  if req.create_repo:
   x=await c.post('https://api.github.com/user/repos',headers=h,json={'name':req.repo,'description':req.description[:350],'private':req.visibility!='public','auto_init':True})
   if x.status_code>=400:raise HTTPException(x.status_code,'Repo creation failed: '+x.text[:350])
  api=f'https://api.github.com/repos/{req.owner}/{req.repo}';info=await c.get(api,headers=h)
  if info.status_code>=400:raise HTTPException(info.status_code,'Repo lookup failed: '+info.text[:300])
  branch=req.branch or info.json().get('default_branch','main');b=await c.get(api+'/branches/'+branch,headers=h)
  if b.status_code==404:
   d=await c.get(api+'/git/ref/heads/'+info.json().get('default_branch','main'),headers=h)
   if d.status_code>=400:raise HTTPException(d.status_code,'Default branch lookup failed')
   q=await c.post(api+'/git/refs',headers=h,json={'ref':'refs/heads/'+branch,'sha':d.json()['object']['sha']})
   if q.status_code>=400:raise HTTPException(q.status_code,'Branch creation failed: '+q.text[:300])
  elif b.status_code>=400:raise HTTPException(b.status_code,'Branch lookup failed')
  uploaded=[]
  for f in sorted(p.rglob('*')):
   if not f.is_file():continue
   rel=f.relative_to(p).as_posix()
   try:safe_path(rel)
   except ValueError:continue
   endpoint=api+'/contents/'+rel;old=await c.get(endpoint,headers=h,params={'ref':branch});body={'message':'Publish generated project: '+rel,'content':base64.b64encode(f.read_bytes()).decode(),'branch':branch}
   if old.status_code==200:body['sha']=old.json().get('sha')
   up=await c.put(endpoint,headers=h,json=body)
   if up.status_code>=400:raise HTTPException(up.status_code,'Upload failed '+rel+': '+up.text[:300])
   uploaded.append(rel)
 return {'success':True,'repository_url':f'https://github.com/{req.owner}/{req.repo}','branch':branch,'published_files':uploaded}
