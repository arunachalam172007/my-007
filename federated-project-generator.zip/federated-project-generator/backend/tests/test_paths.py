import pytest
from app.main import safe_path
@pytest.mark.parametrize('path',['../secret','/absolute','foo\\bar','.env','node_modules/x'])
def test_unsafe(path):
    with pytest.raises(ValueError): safe_path(path)
def test_safe(): assert safe_path('src/main.py')=='src/main.py'
